import { useState } from 'react'
import axios from 'axios'
export default function Calories(){
  const [form,setForm]=useState({sex:'male',weight:80,height:170,age:30,activity:'moderate'})
  const [result,setResult]=useState(null)
  async function calc(e){ 
    e.preventDefault();
    try{ const r = await axios.post((process.env.NEXT_PUBLIC_API_URL || 'https://academia-backend-1-5702.onrender.com') + '/calories', form); setResult(r.data); }catch(err){ alert('Erro') }
  }
  return (<div className="card"><h2>Calculadora de Calorias</h2><form onSubmit={calc}><select value={form.sex} onChange={e=>setForm({...form,sex:e.target.value})}><option value="male">Masculino</option><option value="female">Feminino</option></select><input value={form.weight} onChange={e=>setForm({...form,weight:Number(e.target.value)})} /><input value={form.height} onChange={e=>setForm({...form,height:Number(e.target.value)})} /><input value={form.age} onChange={e=>setForm({...form,age:Number(e.target.value)})} /><select value={form.activity} onChange={e=>setForm({...form,activity:e.target.value})}><option value="sedentary">Sedentário</option><option value="light">Leve</option><option value="moderate">Moderado</option></select><button>Calcular</button></form>{result && <div>TMB: {result.tmb} — TDEE: {result.tdee}</div>}</div>)
}
