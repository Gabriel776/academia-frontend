import { useEffect, useState } from 'react'
import axios from 'axios'
export default function Exercises(){
  const [list,setList]=useState([])
  useEffect(()=>{ axios.get((process.env.NEXT_PUBLIC_API_URL || 'https://academia-backend-1-5702.onrender.com') + '/exercises', { headers: { Authorization: 'Bearer ' + (localStorage.getItem('token')||'') } }).then(r=>setList(r.data)).catch(()=>{}) },[])
  return (<div className="card"><h2>Exercícios</h2>{list.length===0? <p>Nenhum exercício.</p> : list.map(e=>(<div key={e.id}><h3>{e.name}</h3><p>{e.description}</p></div>))}</div>)
}
