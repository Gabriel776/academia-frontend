import { useState } from 'react'
import axios from 'axios'
export default function Premium(){
  const [email,setEmail]=useState(''); const [payment,setPayment]=useState(null)
  async function buy(e){ e.preventDefault(); try{ const token = localStorage.getItem('token')||''; const r = await axios.post((process.env.NEXT_PUBLIC_API_URL || 'https://academia-backend-1-5702.onrender.com') + '/payments/create_preference', { amount:29.9, description:'Plano Premium' }, { headers: { Authorization: 'Bearer ' + token } }); setPayment(r.data); if(r.data && r.data.init_point) window.open(r.data.init_point); }catch(err){ alert('Erro') } }
  return (<div className="card"><h2>Plano Premium</h2><p>Assine para desbloquear conteúdos.</p><form onSubmit={buy}><input placeholder="Seu email" value={email} onChange={e=>setEmail(e.target.value)} /><button>Assinar R$29,90</button></form>{payment && <pre>{JSON.stringify(payment,null,2)}</pre>}</div>)
}
